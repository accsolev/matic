
 <div class="row">
    <div class="col-xl-12 custome-width">
      <div class="card mb-4">
        <div class="card-body">
          <h4 class="mb-4"> Analytics Overview</h4>
          <div class="input-group search-area mb-3">
            <input type="text" class="form-control" id="analyticsSearchInput" placeholder="Search here...">
            <span class="input-group-text">
              <a href="javascript:void(0)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><g clip-path="url(#clip0_1_450)"><path opacity="0.3" d="M14.2929 16.7071C13.9024 16.3166 13.9024 15.6834 14.2929 15.2929C14.6834 14.9024 15.3166 14.9024 15.7071 15.2929L19.7071 19.2929C20.0976 19.6834 20.0976 20.3166 19.7071 20.7071C19.3166 21.0976 18.6834 21.0976 18.2929 20.7071L14.2929 16.7071Z" fill="#452B90"></path><path d="M11 16C13.7614 16 16 13.7614 16 11C16 8.23859 13.7614 6.00002 11 6.00002C8.23858 6.00002 6 8.23859 6 11C6 13.7614 8.23858 16 11 16ZM11 18C7.13401 18 4 14.866 4 11C4 7.13402 7.13401 4.00002 11 4.00002C14.866 4.00002 18 7.13402 18 11C18 14.866 14.866 18 11 18Z" fill="#452B90"></path></g><defs><clipPath id="clip0_1_450"><rect width="24" height="24" fill="white"></rect></clipPath></defs></svg>
              </a>
            </span>
          </div>
          <div id="analyticsContent">
            <div class="text-center text-muted">
              <div class="spinner-border text-primary" role="status"></div>
              <div class="mt-2">Memuat data analytics...</div>
            </div>
          </div>
          <nav id="analyticsPagination" class="mt-3" aria-label="Analytics Page Navigation">
            <ul class="pagination justify-content-center mb-0"></ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- End Analytics Section -->
<script>
function loadAnalytics() {
  const container      = document.getElementById('analyticsContent');
  const pagination     = document.getElementById('analyticsPagination');
  const paginationList = pagination.querySelector('.pagination');
  const searchInput    = document.getElementById('analyticsSearchInput');

  // 1) show loader
  container.innerHTML = `
    <div class="text-center text-muted">
      <div class="spinner-border text-primary" role="status"></div>
      <div class="mt-2">Memuat data analytics...</div>
    </div>`;
  pagination.style.display = 'none';
  paginationList.innerHTML = '';

  fetch('/dashboard/ajax/get-analytics.php')
    .then(res => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    })
    .then(data => {
      // 2) collect all shortlink keys
      const keys = new Set();
      data.perDay   .forEach(r => keys.add(`${r.domain}/${r.short_code}`));
      data.byCountry.forEach(r => keys.add(`${r.domain}/${r.short_code}`));
      data.byDevice .forEach(r => keys.add(`${r.domain}/${r.short_code}`));

      // 3) init group for each
      const group = {};
      keys.forEach(k => {
        group[k] = { perDay: [], byCountry: [], byDevice: [] };
      });

      // 4) distribute into buckets
      data.perDay   .forEach(r => group[`${r.domain}/${r.short_code}`].perDay.push(r));
      data.byCountry.forEach(r => group[`${r.domain}/${r.short_code}`].byCountry.push(r));
      data.byDevice .forEach(r => group[`${r.domain}/${r.short_code}`].byDevice.push(r));

      const fullEntries = Object.entries(group);
      if (fullEntries.length === 0) {
        container.innerHTML = `<div class="alert alert-warning">⚠️ Tidak ada data analytics.</div>`;
        return;
      }

      // pagination & rendering
      const itemsPerPage = 7;
      let currentPage    = 1;
      let filtered       = fullEntries;

      function renderPage(page) {
        const start = (page - 1) * itemsPerPage;
        const slice = filtered.slice(start, start + itemsPerPage);

        container.innerHTML = slice.map(([shortlink, stat], i) => `
          <div class="border rounded mb-4 p-3">
            <div class="d-flex justify-content-between align-items-center">
              <div><strong><i class="fa-solid fa-link"></i> ${shortlink}</strong></div>
              <button class="btn btn-sm btn-outline-primary"
                      data-bs-toggle="collapse"
                      data-bs-target="#detail-${page}-${i}">
                Lihat Detail
              </button>
            </div>
            <div class="collapse mt-3" id="detail-${page}-${i}">
              <div class="table-responsive mb-3">
                <h6>📅 Klik Per Hari</h6>
                <table class="table table-sm table-bordered">
                  <thead><tr><th>Tanggal</th><th>Jumlah Klik</th></tr></thead>
                  <tbody>
                    ${stat.perDay.map(r => `<tr><td>${r.date}</td><td>${r.clicks}</td></tr>`).join('')}
                  </tbody>
                </table>
              </div>
              <div class="table-responsive mb-3">
                <h6>🌍 Berdasarkan Negara</h6>
                <table class="table table-sm table-bordered">
                  <thead><tr><th>Negara</th><th>Jumlah Klik</th></tr></thead>
                  <tbody>
                    ${stat.byCountry.map(r => `<tr><td>${r.country||'Tidak diketahui'}</td><td>${r.clicks}</td></tr>`).join('')}
                  </tbody>
                </table>
              </div>
              <div class="table-responsive">
                <h6>📱 Berdasarkan Perangkat</h6>
                <table class="table table-sm table-bordered">
                  <thead><tr><th>Perangkat</th><th>Jumlah Klik</th></tr></thead>
                  <tbody>
                    ${stat.byDevice.map(r => `<tr><td>${r.device||'Tidak diketahui'}</td><td>${r.clicks}</td></tr>`).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        `).join('');

        // render pagination controls
        const totalPages = Math.ceil(filtered.length / itemsPerPage);
        pagination.style.display = totalPages > 1 ? 'block' : 'none';
        paginationList.innerHTML = '';
        for (let i = 1; i <= totalPages; i++) {
          const li = document.createElement('li');
          li.className = 'page-item' + (i === page ? ' active' : '');
          li.innerHTML = `<a class="page-link" href="#">${i}</a>`;
          li.querySelector('a').addEventListener('click', e => {
            e.preventDefault();
            currentPage = i;
            renderPage(i);
          });
          paginationList.appendChild(li);
        }
      }

      // search filter
      searchInput.addEventListener('input', () => {
        const kw = searchInput.value.toLowerCase().trim();
        filtered = fullEntries.filter(([k]) => k.toLowerCase().includes(kw));
        renderPage(currentPage = 1);
      });

      // initial render
      renderPage(1);
    })
    .catch(err => {
      console.error('Gagal load analytics:', err);
      container.innerHTML = `<div class="alert alert-danger">❌ Gagal memuat data analytics.</div>`;
      pagination.style.display = 'none';
    });
}

// fire immediately on page load
document.addEventListener('DOMContentLoaded', loadAnalytics);
</script>
