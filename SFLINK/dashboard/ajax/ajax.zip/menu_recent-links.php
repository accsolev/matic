  <div class="row">
    <div class="col-xl-12 custome-width">
      <div class="card mb-4">
        <div class="card-body">
          <h4 class="mb-3">Recent Links</h4>
          <div class="input-group search-area mb-3">
            <input type="text" class="form-control" id="searchRecentAjax" placeholder="Search here...">
            <span class="input-group-text">
              <a href="javascript:void(0)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><g clip-path="url(#clip0_1_450)"><path opacity="0.3" d="M14.2929 16.7071C13.9024 16.3166 13.9024 15.6834 14.2929 15.2929C14.6834 14.9024 15.3166 14.9024 15.7071 15.2929L19.7071 19.2929C20.0976 19.6834 20.0976 20.3166 19.7071 20.7071C19.3166 21.0976 18.6834 21.0976 18.2929 20.7071L14.2929 16.7071Z" fill="#452B90"></path><path d="M11 16C13.7614 16 16 13.7614 16 11C16 8.23859 13.7614 6.00002 11 6.00002C8.23858 6.00002 6 8.23859 6 11C6 13.7614 8.23858 16 11 16ZM11 18C7.13401 18 4 14.866 4 11C4 7.13402 7.13401 4.00002 11 4.00002C14.866 4.00002 18 7.13402 18 11C18 14.866 14.866 18 11 18Z" fill="#452B90"></path></g><defs><clipPath id="clip0_1_450"><rect width="24" height="24" fill="white"></rect></clipPath></defs></svg>
              </a>
            </span>
          </div>
          <div id="recentAjaxLoader" class="text-center d-none">
            <div class="spinner-border text-primary" role="status"></div>
            <div class="mt-2 text-muted">Memuat data recent links...</div>
          </div>
          <div id="recentAjaxContent"></div>
          <nav class="mt-3">
            <ul class="pagination justify-content-center" id="paginationAjaxRecent"></ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
  <script>
let recentPage = 1;
let recentKeyword = "";

function loadRecentLinksAjax(page = 1, search = "") {
  const loader = document.getElementById('recentAjaxLoader');
  const content = document.getElementById('recentAjaxContent');
  const pagination = document.getElementById('paginationAjaxRecent');

  recentPage = page;
  recentKeyword = search;

  loader.classList.remove('d-none');
  content.classList.add('d-none');
  pagination.innerHTML = "";

  fetch(`/dashboard/ajax/get-recent-links.php?page=${page}&search=${encodeURIComponent(search)}`)
    .then(res => res.json())
    .then(data => {
      loader.classList.add('d-none');
      content.classList.remove('d-none');
      content.innerHTML = "";

      if (!data.success) {
        content.innerHTML = `<div class="alert alert-danger">❌ Gagal memuat recent links.</div>`;
        return;
      }

      if (data.total === 0) {
        // ✅ Kalau belum ada data sama sekali
        content.innerHTML = `<div class="alert alert-info">ℹ️ Belum ada shortlink yang dibuat.</div>`;
        pagination.innerHTML = "";
        return;
      }

      if (!data.links.length) {
        // ✅ Kalau data ada, tapi hasil pencarian kosong
        content.innerHTML = `<div class="alert alert-warning">❌ Tidak ada hasil ditemukan untuk pencarian ini.</div>`;
        pagination.innerHTML = "";
        return;
      }

    data.links.forEach(link => {
  content.innerHTML += `
    <div class="border rounded p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <i class="fa-solid fa-link"></i> <strong>${link.full_url}</strong><br>
          <small class="text-muted">${link.created_at_formatted}</small>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-sm btn-outline-primary"
    data-id="${link.id}"
    data-short="${link.full_url}"
    data-created="${link.created_at_formatted}"
    data-urls="${(link.destinations||[]).join('|||')}"
    data-fallback="${(link.fallbacks||[]).join('|||')}"
    data-white="${link.white_page || ''}"
    data-allowed="${(link.allowed_countries || []).join(',')}"
    data-blocked="${(link.blocked_countries || []).join(',')}"
    data-device='${JSON.stringify(link.device_targets || [])}'

    data-usemaindomain="${link.use_main_domain ? 1 : 0}"
    data-maindomainid="${link.main_domain_id || ''}"
    data-maindomain="${link.main_domain || ''}"
    data-pathurl='${JSON.stringify(link.path_url || [])}'
    data-fallbackpathurl='${JSON.stringify(link.fallback_path_url || [])}'

    onclick="showModal(this)">
    <i class="fa-solid fa-edit"></i> Edit
  </button>
          <button class="btn btn-sm btn-danger" onclick="deleteShortlink(${link.id}, '${link.full_url}', this)">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </div>
    </div>`;
});

      renderPagination(data.total, data.per_page, data.page);
    })
    .catch(() => {
      loader.classList.add('d-none');
      content.classList.remove('d-none');
      content.innerHTML = `<div class="alert alert-danger">❌ Gagal memuat recent links.</div>`;
    });
}

function renderPagination(total, perPage, currentPage) {
  const totalPages = Math.ceil(total / perPage);
  const pagination = document.getElementById('paginationAjaxRecent');
  pagination.innerHTML = "";

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.className = 'page-item' + (i === currentPage ? ' active' : '');
    li.innerHTML = `<a class="page-link" href="#">${i}</a>`;
    li.querySelector('a').addEventListener('click', function (e) {
      e.preventDefault();
      loadRecentLinksAjax(i, recentKeyword);
    });
    pagination.appendChild(li);
  }
}
document.addEventListener('DOMContentLoaded', loadRecentLinksAjax);
document.getElementById('searchRecentAjax').addEventListener(
  'input',
  debounce(function() {
    recentKeyword = this.value.trim();
    loadRecentLinksAjax(1, recentKeyword);
  }, 350) // delay biar ga spam AJAX
);

</script>