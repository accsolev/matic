<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
require '../../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-danger">🚫 Anda belum login.</div>';
    exit;
}

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'unknown';

function logActivity($pdo, $userId, $username, $action) {
  $now = date('Y-m-d H:i:s');
  $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, username, action, created_at) VALUES (?, ?, ?, ?)");
  $stmt->execute([$userId, $username, $action, $now]);
}

// Ambil tipe user
$stmt = $pdo->prepare("SELECT type FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userType = $stmt->fetchColumn();

// Fungsi ambil limit berdasarkan tipe user
function getDomainCheckLimit($type) {
    $limits = [
        'trial' => 1,
        'medium' => 3,
        'vip' => 30,
        'vipmax' => 500
    ];
    return $limits[$type] ?? 1;
}

$maxLimit = getDomainCheckLimit($userType);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['domains'])) {
    $lines = explode("\n", trim($_POST['domains']));
    $domains = array_map('trim', $lines);
    $domainCount = count($domains);

    if ($domainCount > $maxLimit) {
        echo "<div class='alert alert-warning'>⚠️ Akun <b>$userType</b> hanya dapat memeriksa maksimal <b>$maxLimit</b> domain.</div>";
        $domains = array_slice($domains, 0, $maxLimit);
    }

    $results = [];
    $checkedDomains = [];

    foreach ($domains as $domain) {
        if (!empty($domain)) {
            $url = "https://check.skiddle.id/?domain=" . urlencode($domain);
            $response = @file_get_contents($url);

            if ($response) {
                $json = json_decode($response, true);
                if (isset($json[$domain]['blocked'])) {
                    $status = $json[$domain]['blocked'] ? 'DIBLOKIR ❌' : 'AMAN ✅';
                } else {
                    $status = 'TIDAK DIKETAHUI ⚠️';
                }
            } else {
                $status = 'GAGAL MENGAMBIL DATA ❌';
            }

            $results[] = [$domain, $status];
            $checkedDomains[] = "$domain: $status";
        }
    }

    // ✅ Catat log aktivitas
    if (!empty($checkedDomains)) {
        logActivity($pdo, $userId, $username, "Melakukan cek domain (TrustPositif):\n" . implode("\n", $checkedDomains));
    }

    echo '<div class="card"><div class="card-body"><h5 class="text-center">Hasil Pengecekan</h5><table class="table table-bordered text-center"><thead><tr><th>Domain</th><th>Status</th></tr></thead><tbody>';
    foreach ($results as $row) {
        $statusClass = (strpos($row[1], 'DIBLOKIR') !== false) ? 'text-danger fw-bold' : 'text-success fw-bold';
        echo "<tr><td>" . htmlspecialchars($row[0]) . "</td><td class=\"$statusClass\">" . htmlspecialchars($row[1]) . "</td></tr>";
    }
    echo '</tbody></table></div></div>';
} else {
    echo '<div class="alert alert-warning">❗ Tidak ada domain yang dikirimkan.</div>';
}
?>
