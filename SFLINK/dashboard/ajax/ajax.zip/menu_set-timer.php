      	<?php
		session_start();
date_default_timezone_set('Asia/Jakarta');

// Pastikan user login
require_once __DIR__ . '/../../includes/auth.php';
require_login();
require_once __DIR__ . '/../../includes/db.php';
$userId = $_SESSION['user_id']; // <-- Tambahkan ini!
		// --------- USER CRON ----------
$stmt = $pdo->prepare("SELECT interval_minute, status FROM list_domains WHERE user_id = ? GROUP BY user_id LIMIT 1");
$stmt->execute([$userId]);
$userCron = $stmt->fetch(PDO::FETCH_ASSOC);
$interval = $userCron['interval_minute'] ?? 5;
$status = $userCron['status'] ?? 0;
		?>
		<div class="row">
       <div class="col-xl-12 custome-width">
      <div class="card mb-4">
<div class="card-body">
    <h4 class="mb-3"><i class="fa-solid fa-clock-rotate-left"></i> Pengaturan Cron Job</h4>
     <div class="alert alert-info" role="alert">
             INFO!! Agar hasil lebih optimal dan aman sebaiknya pengecekan minimal 3 menit sekali
             </div>
    <form id="cronSettingsForm">
      <div class="row mb-3">
        <div class="col-md-4">
          <label for="interval_minute" class="form-label">Interval Pengecekan (menit)</label>
          <input type="number" name="interval_minute" id="interval_minute" class="form-control" min="1" required value="<?= htmlspecialchars($interval) ?>">
        </div>
        <div class="col-md-4">
          <label for="status" class="form-label">Status Cron Job</label>
          <select name="status" id="status" class="form-select" required>
            <option value="1" <?= $status == 1 ? 'selected' : '' ?>>✅ Aktif</option>
            <option value="0" <?= $status == 0 ? 'selected' : '' ?>>⛔ Nonaktif</option>
          </select>
        </div>
    
        <div class="col-md-4 g-3 d-flex align-items-end">
          <button type="submit" class="btn btn-primary w-100">
            <i class="fa-solid fa-save"></i> Simpan Pengaturan
          </button>
        </div>
      </div>
    </form>

    <div id="cronSettingMsg" class="mt-2"></div>
  </div>
</div></div></div></div>
<script>
document.getElementById('cronSettingsForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const formData = new FormData(this);

  fetch('/dashboard/ajax/save-cron.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    const msg = document.getElementById('cronSettingMsg');
    msg.className = data.success ? 'alert alert-success' : 'alert alert-danger';
    msg.innerHTML = data.message;
  })
  .catch(() => {
    const msg = document.getElementById('cronSettingMsg');
    msg.className = 'alert alert-danger';
    msg.innerHTML = '❌ Gagal menyimpan pengaturan';
  });
});
</script>