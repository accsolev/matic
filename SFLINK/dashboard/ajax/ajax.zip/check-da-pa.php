<?php

// Ambil input domain (bisa multiple, dipisah baris)
$domainsInput = trim($_POST['domain'] ?? '');
$domains = array_filter(array_map('trim', explode("\n", $domainsInput)));

if (empty($domains)) {
    exit("<div class='alert alert-danger'>❌ Tidak ada domain valid.</div>");
}

echo "<div class='table-responsive'><table class='table table-bordered'><thead>
<tr>
<th>Domain</th><th>DA</th><th>PA</th><th>Spam</th><th>Backlink</th><th>MT</th><th>MR</th>
<th>NOF</th><th>RED</th><th>DEL</th><th>History</th><th>Registered</th><th>Expired</th>
</tr></thead><tbody>";

foreach ($domains as $domain) {
    $url = "https://xeo.my.id/checker/free/moz/?domain=" . urlencode($domain);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0',
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30
    ]);
    $html = curl_exec($ch);
    curl_close($ch);

    if (!$html || strpos($html, 'table') === false) {
        echo "<tr><td>{$domain}</td><td colspan='12'>❌ Gagal mengambil data.</td></tr>";
        continue;
    }

    // Ambil semua tabel
    preg_match_all('~<table[^>]*>(.*?)</table>~is', $html, $tables);
    if (count($tables[1]) < 3) {
        echo "<tr><td>{$domain}</td><td colspan='12'>❌ Format data tidak lengkap / parsing gagal.</td></tr>";
        continue;
    }

    // Tabel 1: DA, PA, SS, BL, MT, MR
    $dom1 = new DOMDocument();
    @$dom1->loadHTML("<table>{$tables[1][0]}</table>");
    $row1 = (new DOMXPath($dom1))->query('//tr[2]/td');

    // Tabel 2: NOF, RED, DEL
    $dom2 = new DOMDocument();
    @$dom2->loadHTML("<table>{$tables[1][1]}</table>");
    $row2 = (new DOMXPath($dom2))->query('//tr[2]/td');

    // Tabel 3: History, Registered, Expired
    $dom3 = new DOMDocument();
    @$dom3->loadHTML("<table>{$tables[1][2]}</table>");
    $row3 = (new DOMXPath($dom3))->query('//tr[2]/td');

    if ($row1->length < 6 || $row2->length < 3 || $row3->length < 3) {
        echo "<tr><td>{$domain}</td><td colspan='12'>❌ Format data tidak lengkap / parsing gagal.</td></tr>";
        continue;
    }

    $da   = $row1->item(0)->textContent;
    $pa   = $row1->item(1)->textContent;
    $ss   = strip_tags($row1->item(2)->C14N()); // ambil teks % tanpa tag <b>
    $bl   = $row1->item(3)->textContent;
    $mt   = $row1->item(4)->textContent;
    $mr   = $row1->item(5)->textContent;

    $nof  = $row2->item(0)->textContent;
    $red  = $row2->item(1)->textContent;
    $del  = $row2->item(2)->textContent;

    $hist = $row3->item(0)->textContent;
    $reg  = $row3->item(1)->textContent;
    $exp  = $row3->item(2)->textContent;

    echo "<tr><td>{$domain}</td><td>{$da}</td><td>{$pa}</td><td>{$ss}</td><td>{$bl}</td>
    <td>{$mt}</td><td>{$mr}</td><td>{$nof}</td><td>{$red}</td><td>{$del}</td><td>{$hist}</td><td>{$reg}</td><td>{$exp}</td></tr>";
}

echo "</tbody></table></div>";
?>