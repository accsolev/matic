	<?php
// --------- INIT & AUTH -----------
session_start();
date_default_timezone_set('Asia/Jakarta');
require_once __DIR__ . '/../../includes/auth.php';
require_login();
require_once __DIR__ . '/../../includes/db.php';

$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function formatTanggalIndonesia($datetime) {
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $timestamp = strtotime($datetime);
    $tgl = date('d', $timestamp); $bln = $bulan[(int)date('m', $timestamp)]; $thn = date('Y', $timestamp); $jam = date('H:i', $timestamp);
    return "$tgl $bln $thn $jam";
}

// Ambil user info dari session
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo "<div class='alert alert-danger'>Session expired. Silakan login ulang.</div>";
    exit;
}
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];

// --------- DATA UTAMA USER -----------
$userDataStmt = $pdo->prepare("
    SELECT u.type, u.telegram_id,
        COALESCE(link_stats.total_links, 0) as total_links,
        COALESCE(link_stats.total_clicks, 0) as total_clicks,
        COALESCE(link_stats.today_clicks, 0) as today_clicks,
        COALESCE(domains.total_domains, 0) as total_domains
    FROM users u
    LEFT JOIN (
        SELECT user_id, COUNT(*) AS total_links, SUM(clicks) AS total_clicks,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN clicks ELSE 0 END) AS today_clicks
        FROM links WHERE user_id = ? GROUP BY user_id
    ) link_stats ON u.id = link_stats.user_id
    LEFT JOIN (
        SELECT user_id, COUNT(*) as total_domains
        FROM list_domains WHERE user_id = ? GROUP BY user_id
    ) domains ON u.id = domains.user_id
    WHERE u.id = ?
");
$userDataStmt->execute([$userId, $userId, $userId]);
$userData = $userDataStmt->fetch(PDO::FETCH_ASSOC);
$totalLinks = $userData['total_links'];
$totalClicks = $userData['total_clicks'];
$todayClicks = $userData['today_clicks'];
$totalDomains = $userData['total_domains'];
$userType = $userData['type'];
$userTelegramId = $userData['telegram_id'];

// Total Klik Hari Ini
$stmt = $pdo->prepare("
  SELECT COUNT(*) 
  FROM analytics a 
  JOIN links l ON a.link_id = l.id 
  WHERE DATE(a.created_at) = CURDATE() AND l.user_id = ?
");
$stmt->execute([$userId]);
$todayClicks = $stmt->fetchColumn() ?? 0;

// --------- RECENT LINKS & TOP SHORTLINK ----------
$recentLinksStmt = $pdo->prepare("
    SELECT l.id, l.short_code, d.domain, l.created_at
    FROM links l JOIN domains d ON l.domain_id = d.id
    WHERE l.user_id = ? ORDER BY l.created_at DESC LIMIT 6
");
$recentLinksStmt->execute([$userId]);
$recentLinks = $recentLinksStmt->fetchAll(PDO::FETCH_ASSOC);

$topShortlinkStmt = $pdo->prepare("
    SELECT CONCAT(d.domain, '/', l.short_code) AS full_url, l.clicks
    FROM links l JOIN domains d ON l.domain_id = d.id
    WHERE l.user_id = ? ORDER BY l.clicks DESC LIMIT 1
");
$topShortlinkStmt->execute([$userId]);
$topShortlinkData = $topShortlinkStmt->fetch(PDO::FETCH_ASSOC);
$topShortlinkUrl = $topShortlinkData['full_url'] ?? 'Belum Ada';
$topShortlinkClicks = $topShortlinkData['clicks'] ?? 0;

// --------- CHART DATA: KLIK (Optimized) ---------
// DAILY CHART (7 Hari)
$chartDates = [];
$dateStart = date('Y-m-d', strtotime('-6 days'));
$dateEnd = date('Y-m-d');
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartDates[$date] = 0;
}
$analyticsStmt = $pdo->prepare("
    SELECT DATE(a.created_at) AS date, COUNT(*) AS total
    FROM analytics a JOIN links l ON a.link_id = l.id
    WHERE l.user_id = ? AND a.created_at >= ? AND a.created_at <= ?
    GROUP BY DATE(a.created_at)
    ORDER BY DATE(a.created_at) ASC
");
$analyticsStmt->execute([$userId, $dateStart . " 00:00:00", $dateEnd . " 23:59:59"]);
foreach ($analyticsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $chartDates[$row['date']] = (int)$row['total'];
}

// WEEKLY CHART (7 Minggu)
$weeklyChart = [];
$weeklyRange = [];
for ($i = 6; $i >= 0; $i--) {
    $monday = date('Y-m-d', strtotime("monday -$i week"));
    $sunday = date('Y-m-d', strtotime("$monday +6 days"));
    $label = date('d M', strtotime($monday)) . ' - ' . date('d M', strtotime($sunday));
    $weeklyChart[$label] = 0;
    $weeklyRange[$label] = [$monday, $sunday];
}
$weeklyStmt = $pdo->prepare("
    SELECT COUNT(*) as total
    FROM analytics a JOIN links l ON a.link_id = l.id
    WHERE l.user_id = ? AND a.created_at BETWEEN ? AND ?
");
foreach ($weeklyRange as $label => $range) {
    $weeklyStmt->execute([$userId, $range[0] . " 00:00:00", $range[1] . " 23:59:59"]);
    $weeklyChart[$label] = (int)$weeklyStmt->fetchColumn();
}

// MONTHLY CHART (12 Bulan)
$monthlyChart = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i month"));
    $label = date('M Y', strtotime($month));
    $monthlyChart[$label] = 0;
}
$monthlyStmt = $pdo->prepare("
    SELECT DATE_FORMAT(a.created_at, '%b %Y') AS bulan, COUNT(*) AS total
    FROM analytics a JOIN links l ON a.link_id = l.id
    WHERE l.user_id = ? AND a.created_at >= DATE_FORMAT(CURDATE() - INTERVAL 11 MONTH, '%Y-%m-01')
    GROUP BY bulan
    ORDER BY MIN(a.created_at)
");
$monthlyStmt->execute([$userId]);
foreach ($monthlyStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $monthlyChart[$row['bulan']] = (int)$row['total'];
}

// --------- AKTIVITAS TERAKHIR ----------
$activityLogsStmt = $pdo->prepare("SELECT action, created_at FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$activityLogsStmt->execute([$userId]);
$activityLogs = $activityLogsStmt->fetchAll(PDO::FETCH_ASSOC);

// --------- DEVICE CLICK SUMMARY ----------
$deviceClicksStmt = $pdo->prepare("
    SELECT
        SUM(CASE WHEN LOWER(a.device) = 'desktop' THEN 1 ELSE 0 END) AS desktop,
        SUM(CASE WHEN LOWER(a.device) = 'mobile' THEN 1 ELSE 0 END) AS mobile,
        SUM(CASE WHEN LOWER(a.device) = 'tablet' THEN 1 ELSE 0 END) AS tablet,
        COUNT(*) AS total
    FROM analytics a JOIN links l ON a.link_id = l.id
    WHERE l.user_id = ?
");
$deviceClicksStmt->execute([$userId]);
$deviceRow = $deviceClicksStmt->fetch(PDO::FETCH_ASSOC);
$desktopClicks = (int)$deviceRow['desktop'];
$mobileClicks = (int)$deviceRow['mobile'];
$tabletClicks = (int)$deviceRow['tablet'];
$allClicks = (int)$deviceRow['total'];
$unknownClicks = $allClicks - ($desktopClicks + $mobileClicks + $tabletClicks);

// --------- TOP 3 REFERRER ----------
$referrerStmt = $pdo->prepare("
    SELECT
      CASE WHEN referrer IS NULL OR referrer = '' THEN 'Direct'
           ELSE LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(referrer, '://', -1), '/', 1)) END AS domain,
      COUNT(*) AS total
    FROM analytics a JOIN links l ON l.id = a.link_id
    WHERE l.user_id = ? GROUP BY domain ORDER BY total DESC LIMIT 3
");
$referrerStmt->execute([$userId]);
$topDomains = array_column($referrerStmt->fetchAll(PDO::FETCH_ASSOC), 'domain');

// --------- REFERRER CHART DATA ----------
// Fill $referrers for Morris Donut!
$referrers = [];
if ($topDomains) {
    $placeholders = implode(',', array_fill(0, count($topDomains), '?'));
    $sql = "
        SELECT
            CASE WHEN a.referrer IS NULL OR a.referrer = '' THEN 'Direct'
                 ELSE LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(a.referrer, '://', -1), '/', 1)) END AS domain,
            COUNT(*) AS cnt
        FROM analytics a JOIN links l ON l.id = a.link_id
        WHERE l.user_id = ?
            AND (
              CASE WHEN a.referrer IS NULL OR a.referrer = '' THEN 'Direct'
                   ELSE LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(a.referrer, '://', -1), '/', 1)) END
            ) IN ($placeholders)
        GROUP BY domain
    ";
    $params = array_merge([$userId], $topDomains);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $referrers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Data for Morris.Area (chartData/ykeys)
$days = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $days[$d] = ['day' => date('D', strtotime($d))];
    foreach ($topDomains as $dom) $days[$d][$dom] = 0;
}
$chartData = []; $ykeys = [];
if (!empty($topDomains)) {
    $placeholders = implode(',', array_fill(0, count($topDomains), '?'));
    $sql2 = "
      SELECT
        CASE WHEN a.referrer IS NULL OR a.referrer = '' THEN 'Direct'
             ELSE LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(a.referrer, '://', -1), '/', 1)) END AS domain,
        DATE(a.click_date) AS d,
        COUNT(*) AS cnt
      FROM analytics a JOIN links l ON l.id = a.link_id
      WHERE l.user_id = ?
        AND DATE(a.click_date) BETWEEN DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND CURDATE()
        AND (
          CASE WHEN a.referrer IS NULL OR a.referrer = '' THEN 'Direct'
               ELSE LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(a.referrer, '://', -1), '/', 1)) END
        ) IN ($placeholders)
      GROUP BY domain, d
    ";
    $params = array_merge([$userId], $topDomains);
    $stmt2 = $pdo->prepare($sql2); $stmt2->execute($params);
    foreach ($stmt2->fetchAll(PDO::FETCH_ASSOC) as $r) if (isset($days[$r['d']][$r['domain']])) $days[$r['d']][$r['domain']] = (int)$r['cnt'];
    $chartData = array_values($days); $ykeys = array_values($topDomains);
} else {
    $chartData = array_values($days); $ykeys = [];
}
$ykeys = ['google.com', 'direct']; // atau sesuai data aslimu
$totals = [
  'google.com' => 2,
  'direct' => 1
];
$referrerData = [];
foreach($ykeys as $label) {
  $referrerData[] = [
    'label' => ucfirst($label), 
    'value' => (int)@$totals[$label]
  ];
}
// --------- END OF BACKEND ---------
?>
	<div class="row">
					
  <div class="owl-carousel counter-carousel owl-theme">
  <!-- Total Visit -->
  <div class="item">
    <div class="card border-0 zoom-in bg-primary-subtle shadow-none">
      <div class="card-body">
        <div class="text-center">
          <!-- Ikon Mata (Visit) -->
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z" stroke="#4f46e5" stroke-width="2" fill="none"/>
            <circle cx="12" cy="12" r="4" stroke="#4f46e5" stroke-width="2" fill="none"/>
          </svg>
          <p class="fw-semibold fs-3 text-primary mb-1 mt-2">Total Visit</p>
          <h5 class="fw-semibold text-primary mb-0"><?= number_format($totalClicks) ?></h5>
        </div>
      </div>
    </div>
  </div>

  <!-- Total Shortlink -->
  <div class="item">
    <div class="card border-0 zoom-in bg-info-subtle shadow-none">
      <div class="card-body">
        <div class="text-center">
          <!-- Ikon Rantai (Shortlink) -->
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <path d="M10.59 13.41a2 2 0 010-2.82l2-2a2 2 0 012.82 2l-.88.88" stroke="#0ea5e9" stroke-width="2" fill="none"/>
            <path d="M13.41 10.59a2 2 0 012.82 0l2 2a2 2 0 01-2 2l-.88-.88" stroke="#0ea5e9" stroke-width="2" fill="none"/>
            <path d="M14.83 9.17l-5.66 5.66" stroke="#0ea5e9" stroke-width="2" fill="none"/>
          </svg>
          <p class="fw-semibold fs-3 text-info mb-1 mt-2">Total Shortlink</p>
          <h5 class="fw-semibold text-info mb-0"><?= number_format($totalLinks) ?></h5>
        </div>
      </div>
    </div>
  </div>

  <!-- Total Domains -->
  <div class="item">
    <div class="card border-0 zoom-in bg-success-subtle shadow-none">
      <div class="card-body">
        <div class="text-center">
          <!-- Ikon Globe (Domains) -->
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#22c55e" stroke-width="2" fill="none"/>
            <path d="M2 12h20M12 2v20M5.64 5.64l12.72 12.72M5.64 18.36l12.72-12.72" stroke="#22c55e" stroke-width="2"/>
          </svg>
          <p class="fw-semibold fs-3 text-success mb-1 mt-2">Total Domains</p>
          <h5 class="fw-semibold text-success mb-0"><?= number_format($totalDomains) ?></h5>
        </div>
      </div>
    </div>
  </div>

  <!-- Klik Hari Ini -->
  <div class="item">
    <div class="card border-0 zoom-in bg-warning-subtle shadow-none">
      <div class="card-body">
        <div class="text-center">
          <!-- Ikon Kalender -->
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#f59e42" stroke-width="2" fill="none"/>
            <rect x="7" y="10" width="10" height="8" stroke="#f59e42" stroke-width="2" fill="none"/>
            <line x1="9" y1="6" x2="9" y2="8" stroke="#f59e42" stroke-width="2"/>
            <line x1="15" y1="6" x2="15" y2="8" stroke="#f59e42" stroke-width="2"/>
          </svg>
          <p class="fw-semibold fs-3 text-warning mb-1 mt-2">Klik Hari Ini</p>
          <h5 class="fw-semibold text-warning mb-0"><?= number_format($todayClicks) ?></h5>
        </div>
      </div>
    </div>
  </div>
  
  <div class="item">
  <div class="card border-0 zoom-in bg-danger-subtle shadow-none">
    <div class="card-body">
      <div class="text-center">
        <!-- Ikon 🔗 -->
        <svg width="50" height="50" fill="none" viewBox="0 0 24 24">
          <path d="M7 17L17 7" stroke="#ef4444" stroke-width="2" />
          <rect x="2" y="15" width="8" height="7" rx="4" transform="rotate(-45 2 15)" stroke="#ef4444" stroke-width="2"/>
          <rect x="14" y="3" width="8" height="7" rx="4" transform="rotate(45 14 3)" stroke="#ef4444" stroke-width="2"/>
        </svg>
        <p class="fw-semibold fs-3 text-danger mb-1 mt-2">Top Shortlink (<small> <?= number_format($topShortlinkClicks) ?> Klik</small>)</p>
        <div class="small text-secondary mb-1"><?= htmlspecialchars($topShortlinkUrl) ?></div>
      </div>
    </div>
  </div>
</div>


<!-- Top Referrer -->
<?php
$topReferrer = isset($topDomains[0]) ? ucfirst($topDomains[0]) : 'Direct';
?>
<div class="item">
  <div class="card border-0 zoom-in bg-warning-subtle shadow-none">
    <div class="card-body">
      <div class="text-center">
        <!-- Ikon Chain/World -->
        <svg width="50" height="50" fill="none" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" stroke="#f59e42" stroke-width="2"/>
          <path d="M12 2v20M2 12h20" stroke="#f59e42" stroke-width="2"/>
        </svg>
        <p class="fw-semibold fs-3 text-warning mb-1 mt-2">Top Referrer</p>
        <h5 class="fw-semibold text-warning mb-0"><?= htmlspecialchars($topReferrer) ?></h5>
      </div>
    </div>
  </div>
</div>

</div>
 <!-- Statistik & Recent Links -->
<div class="col-xl-8 custome-width">
  <div class="card flex-fill h-100 w-100">
    <div class="card-header border-0 pb-0 d-flex justify-content-between align-items-center">
      <h4 class="h-title mb-0">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" class="me-2"><path d="M3 17V21H7V17" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/><path d="M9 13V21H15V13" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/><path d="M17 8V21H21V8" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/></svg>
        Statistik
      </h4>
      <ul class="revnue-tab nav nav-tabs" id="statistikTab" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active" id="daily-tab" data-bs-toggle="tab" data-bs-target="#daily" type="button" role="tab" aria-controls="daily" aria-selected="true">Daily</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="weekly-tab" data-bs-toggle="tab" data-bs-target="#weekly" type="button" role="tab" aria-controls="weekly" aria-selected="false">Weekly</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly" aria-selected="false">Monthly</button>
        </li>
      </ul>
    </div>
    <div class="card-body">
      <div class="tab-content" id="statistikTabContent">
        <div class="tab-pane fade show active" id="daily" role="tabpanel" aria-labelledby="daily-tab">
          <div id="statistikDailyChart" style="min-height: 280px;"></div>
        </div>
        <div class="tab-pane fade" id="weekly" role="tabpanel" aria-labelledby="weekly-tab">
          <div id="statistikWeeklyChart" style="min-height: 280px;"></div>
        </div>
        <div class="tab-pane fade" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
          <div id="statistikMonthlyChart" style="min-height: 280px;"></div>
        </div>
      </div>
    </div>
  </div>
</div>


    <div class="col-xl-4 custome-width">
      <div class="card flex-fill h-100 w-100">
        <div class="card-header d-flex justify-content-between align-items-center py-2">
          <h6 class="mb-0"> <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" stroke="#5b6d81" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="me-2" viewBox="0 0 24 24">
  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
  <path d="M5 15H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2"/>
</svg>
Recent Link</h6>
          <span class="badge bg-secondary"><?= count($recentLinks) ?> Links</span>
        </div>
        <ul class="list-group" id="recentAjaxDashboard">
          <?php if (!empty($recentLinks)): ?>
            <?php
              $linkIds = array_column($recentLinks, 'id');
              $in  = implode(',', array_fill(0, count($linkIds), '?'));
              $destStmt = $pdo->prepare("SELECT link_id, COUNT(*) AS total FROM redirect_urls WHERE link_id IN ($in) GROUP BY link_id");
              $destStmt->execute($linkIds);
              $destCounts = $destStmt->fetchAll(PDO::FETCH_KEY_PAIR);
              $fbStmt = $pdo->prepare("SELECT link_id, COUNT(*) AS total FROM fallback_urls WHERE link_id IN ($in) GROUP BY link_id");
              $fbStmt->execute($linkIds);
              $fallbackCounts = $fbStmt->fetchAll(PDO::FETCH_KEY_PAIR);
            ?>
            <?php foreach ($recentLinks as $link):
              $fullUrl = "{$link['domain']}/{$link['short_code']}";
              $destTotal = $destCounts[$link['id']] ?? 0;
              $fallbackTotal = $fallbackCounts[$link['id']] ?? 0;
            ?>
              <li class="list-group-item p-2">
                <div role="button" class="d-flex justify-content-between copy-link" data-url="<?= htmlspecialchars($fullUrl) ?>" title="Klik untuk copy URL">
                  <div class="text-truncate" style="max-width: 60%;">
                    <strong><?= htmlspecialchars($fullUrl) ?></strong><br>
                    <small class="text-muted">Dibuat: <?= htmlspecialchars(formatTanggalIndonesia($link['created_at'])) ?></small>
                  </div>
                  <div class="text-end">
                    <span class="badge rounded-pill bg-primary px-3"><?= $destTotal ?> URL</span>
                    <span class="badge rounded-pill bg-info px-3"><?= $fallbackTotal ?> Fallback</span>
                  </div>
                </div>
              </li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="list-group-item text-center text-muted">
              <strong>Belum ada link</strong><br>
              <small>Mulai buat shortlink baru 🚀</small>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

  
<!-- ROW DENGAN FLEX: Pastikan tinggi sama rata & ada space antar card -->
<div class="row g-4 align-items-stretch">
  <!-- Click by Device -->
  <div class="col-xl-6 d-flex">
    <div class="card flex-fill h-60 w-100">
      <div class="card-header border-0 pb-0 flex-wrap">
        <div class="d-flex flex-wrap">
          <h4 class="h-title mb-0 me-4">
           <svg width="22" height="22" viewBox="0 0 24 24" fill="none" class="me-2" xmlns="http://www.w3.org/2000/svg">
  <!-- Desktop -->
  <rect x="2" y="6" width="13" height="10" rx="2" stroke="#5b6d81" stroke-width="2"/>
  <rect x="8" y="18" width="3" height="2" rx="1" stroke="#5b6d81" stroke-width="2"/>
  <!-- Tablet -->
  <rect x="17" y="7" width="5" height="8" rx="1" stroke="#5b6d81" stroke-width="2"/>
  <circle cx="19.5" cy="14.5" r="0.7" fill="#5b6d81"/>
  <!-- Smartphone -->
  <rect x="13" y="9" width="3" height="6" rx="1" stroke="#5b6d81" stroke-width="2"/>
  <circle cx="14.5" cy="14.5" r="0.6" fill="#5b6d81"/>
</svg>
            Click By Device
          </h4>
        </div>
      </div>
 <div class="card-body px-0 d-flex align-items-start" style="gap: 30px; min-height: 320px;">
      <div id="deviceDonut" style="width:320px;height:220px;"></div>
      <div class="flex-grow-1">
        <table class="table table-striped mb-0">
          <thead>
            <tr>
              <th>Device</th>
              <th>Clicks</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>Desktop</td><td><?= $desktopClicks ?></td></tr>
            <tr><td>Mobile</td><td><?= $mobileClicks ?></td></tr>
            <tr><td>Tablet</td><td><?= $tabletClicks ?></td></tr>
            <tr><td>Unknown</td><td><?= $unknownClicks ?></td></tr>
          </tbody>
        </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Click by Referrer -->
  <div class="col-xl-6 d-flex">
    <div class="card flex-fill h-60 w-100">
      <div class="card-header border-0 pb-0 flex-wrap">
        <div class="d-flex flex-wrap">
          <h4 class="h-title mb-0 me-4">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" class="me-2" xmlns="http://www.w3.org/2000/svg">
  <!-- Link kiri -->
  <path d="M8.5 15.5L7.1 16.9C5.3 18.7 2.7 18.7 0.9 16.9C-0.9 15.1 -0.9 12.5 0.9 10.7L4.6 7C6.4 5.2 9 5.2 10.8 7" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/>
  <!-- Link kanan -->
  <path d="M15.5 8.5L16.9 7.1C18.7 5.3 21.3 5.3 23.1 7.1C24.9 8.9 24.9 11.5 23.1 13.3L19.4 17C17.6 18.8 15 18.8 13.2 17" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/>
  <!-- Rantai penghubung -->
  <path d="M8 16L16 8" stroke="#5b6d81" stroke-width="2" stroke-linecap="round"/>
</svg>
            Click by Referrer
          </h4>
        </div>
      </div>
       <div class="card-body px-0 d-flex align-items-start" style="gap: 30px; min-height: 320px;">
      <div id="referrerDonut" style="width:320px;height:220px;"></div>
      <div class="flex-grow-1">
        <div id="referrerLegend"></div>
        <table class="table table-striped mb-0 mt-3">
          <thead>
            <tr>
              <th>Referrer</th>
              <th>Clicks</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($ykeys as $label): ?>
              <tr>
                <td><?= htmlspecialchars(ucfirst($label)) ?></td>
                <td><?= (int)@$totals[$label] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
    </div>
  </div>  </div>  </div>

  <!-- Clicks by Location -->
  <div class="col-xl-12 d-flex">
    <div class="card flex-fill w-100">
      <div class="card-header border-0 pb-0 flex-wrap">
        <div class="d-flex flex-wrap">
          <h4 class="h-title mb-0 me-4">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" class="me-2" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="10" r="4" stroke="#5b6d81" stroke-width="2"/>
              <path d="M12 22C12 22 20 14.36 20 10C20 5.58 16.42 2 12 2C7.58 2 4 5.58 4 10C4 14.36 12 22 12 22Z" stroke="#5b6d81" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            Clicks by Location
          </h4>
        </div>
      </div>
      <div class="card-body px-0 pt-3">
        <?php
          // Pastikan $userId sudah dari session
          $countryStmt = $pdo->prepare("SELECT a.country, COUNT(*) AS clicks FROM analytics a JOIN links l ON a.link_id = l.id WHERE l.user_id = ? GROUP BY a.country ORDER BY clicks DESC");
          $countryStmt->execute([$userId]);
          $countryStats = $countryStmt->fetchAll(PDO::FETCH_ASSOC);
          $totalCountryClicks = array_sum(array_column($countryStats, 'clicks'));

          $cityStmt = $pdo->prepare("SELECT a.city, COUNT(*) AS clicks FROM analytics a JOIN links l ON a.link_id = l.id WHERE l.user_id = ? GROUP BY a.city ORDER BY clicks DESC");
          $cityStmt->execute([$userId]);
          $cityStats = $cityStmt->fetchAll(PDO::FETCH_ASSOC);
          $totalCityClicks = array_sum(array_column($cityStats, 'clicks'));
        ?>
        <ul class="nav nav-tabs mb-3" id="locTabs" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="tab-country" data-bs-toggle="tab" data-bs-target="#pane-country" type="button" role="tab">Countries</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tab-city" data-bs-toggle="tab" data-bs-target="#pane-city" type="button" role="tab">Cities</button>
          </li>
        </ul>
        <div class="tab-content">
          <!-- COUNTRIES -->
          <div class="tab-pane fade show active" id="pane-country" role="tabpanel">
            <div class="table-responsive">
              <table id="tbl-country" class="table table-sm table-striped mb-4">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Country</th>
                    <th>Clicks</th>
                    <th>%</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($countryStats as $i => $row): 
                    $pct = $totalCountryClicks
                      ? number_format($row['clicks'] / $totalCountryClicks * 100, 1) . '%'
                      : '0%';
                  ?>
                  <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= htmlspecialchars($row['country'] ?: 'Unknown') ?></td>
                    <td><?= $row['clicks'] ?></td>
                    <td><?= $pct ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- CITIES -->
          <div class="tab-pane fade" id="pane-city" role="tabpanel">
            <div class="table-responsive">
              <table id="tbl-city" class="table table-sm table-striped mb-4">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>City</th>
                    <th>Clicks</th>
                    <th>%</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($cityStats as $i => $row): 
                    $pct = $totalCityClicks
                      ? number_format($row['clicks'] / $totalCityClicks * 100, 1) . '%'
                      : '0%';
                  ?>
                  <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= htmlspecialchars($row['city'] ?: 'Unknown') ?></td>
                    <td><?= $row['clicks'] ?></td>
                    <td><?= $pct ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div> <!-- .tab-content -->
      </div>
    </div>
  </div>
</div>

  <script>
    // === DATA DARI PHP ===
  // Daily, Weekly, Monthly ambil dari PHP variable
  var dailyLabels   = <?= json_encode(array_keys($chartDates)) ?>;
  var dailyClicks   = <?= json_encode(array_values($chartDates)) ?>;
  var weeklyLabels  = <?= json_encode(array_keys($weeklyChart ?? [])) ?>;
  var weeklyClicks  = <?= json_encode(array_values($weeklyChart ?? [])) ?>;
  var monthlyLabels = <?= json_encode(array_keys($monthlyChart ?? [])) ?>;
  var monthlyClicks = <?= json_encode(array_values($monthlyChart ?? [])) ?>;

  // Device clicks (pie/donut)
  var deviceClicks = [
    { label: "Desktop", value: <?= $desktopClicks ?> },
    { label: "Mobile",  value: <?= $mobileClicks ?> },
    { label: "Tablet",  value: <?= $tabletClicks ?> },
    { label: "Unknown", value: <?= $unknownClicks ?> }
  ];

  // Contoh Referrer (kalau mau donut juga)
  var referrerClicks = [
    <?php foreach($ykeys as $i => $label): ?>
      { label: "<?= addslashes(ucfirst($label)) ?>", value: <?= (int)@$totals[$label] ?> },
    <?php endforeach; ?>
  ];
// Pastikan sudah ada <div id="statistikDailyChart"></div> dst
var dailyOpt = {
  chart: { type: 'bar', height: 300 },
  series: [{ name: "Klik", data: dailyClicks }],
  xaxis: { categories: dailyLabels }
};
new ApexCharts(document.querySelector("#statistikDailyChart"), dailyOpt).render();

var weeklyOpt = {
  chart: { type: 'bar', height: 300 },
  series: [{ name: "Klik", data: weeklyClicks }],
  xaxis: { categories: weeklyLabels }
};
new ApexCharts(document.querySelector("#statistikWeeklyChart"), weeklyOpt).render();

var monthlyOpt = {
  chart: { type: 'bar', height: 300 },
  series: [{ name: "Klik", data: monthlyClicks }],
  xaxis: { categories: monthlyLabels }
};
new ApexCharts(document.querySelector("#statistikMonthlyChart"), monthlyOpt).render();

  </script>
  
  
  <script>
  // === DATA DARI PHP (pakai variabel yang sudah ada) ===
var deviceLabels = ["Desktop", "Mobile", "Tablet", "Unknown"];
var deviceSeries = [
  <?= $desktopClicks ?>,
  <?= $mobileClicks ?>,
  <?= $tabletClicks ?>,
  <?= $unknownClicks ?>
];

// Referrer
var referrerLabels = [
  <?php foreach($ykeys as $label): ?>
    "<?= addslashes(ucfirst($label)) ?>",
  <?php endforeach; ?>
];
var referrerSeries = [
  <?php foreach($ykeys as $label): ?>
    <?= (int)@$totals[$label] ?>,
  <?php endforeach; ?>
];

// === DEVICE DONUT ===
var deviceChart = new ApexCharts(document.querySelector("#deviceDonut"), {
  chart: {
    type: 'donut',
    height: 220,
    fontFamily: 'inherit',
    background: 'transparent'
  },
  series: deviceSeries,
  labels: deviceLabels,
  colors: ['#0088FE','#00C49F','#FFBB28','#FF8042'],
  legend: {
    show: true,
    position: 'bottom',
    fontSize: '15px',
    markers: { width:12, height:12, radius:12 }
  },
  dataLabels: {
    enabled: true,
    formatter: function(val, opts) {
      return deviceSeries[opts.seriesIndex] + " klik";
    }
  },
  tooltip: {
    y: { formatter: function(val, opts){
      return deviceLabels[opts.seriesIndex]+": "+val+" klik";
    }}
  },
  plotOptions: {
    pie: {
      donut: { size: '70%' }
    }
  },
  stroke: { width: 2 },
  responsive: [{ breakpoint: 540, options: { chart: { width: "100%" } } }]
});
deviceChart.render();

// === REFERRER DONUT ===
var referrerChart = new ApexCharts(document.querySelector("#referrerDonut"), {
  chart: {
    type: 'donut',
    height: 220,
    fontFamily: 'inherit',
    background: 'transparent'
  },
  series: referrerSeries,
  labels: referrerLabels,
  colors: ['#1921fa','#10ca93','#ff5c00','#ffaa2b','#575df3','#f57f3d','#23e2aa'],
  legend: {
    show: true,
    position: 'bottom',
    fontSize: '15px',
    markers: { width:12, height:12, radius:12 }
  },
  dataLabels: {
    enabled: true,
    formatter: function(val, opts) {
      return referrerSeries[opts.seriesIndex] + " klik";
    }
  },
  tooltip: {
    y: { formatter: function(val, opts){
      return referrerLabels[opts.seriesIndex]+": "+val+" klik";
    }}
  },
  plotOptions: {
    pie: {
      donut: { size: '70%' }
    }
  },
  stroke: { width: 2 },
  responsive: [{ breakpoint: 540, options: { chart: { width: "100%" } } }]
});
referrerChart.render();

  </script>