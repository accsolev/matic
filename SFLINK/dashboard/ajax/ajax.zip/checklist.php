<?php
header('Content-Type: application/json');

// Ambil input
$domain = $_GET['domain'] ?? '';
if (!$domain) {
  echo json_encode(['status' => 'error', 'message' => 'Domain kosong']);
  exit;
}

// 🔥 Paksa filter: buang http/https dan path/query
$parsed = parse_url(trim($domain));
$cleanDomain = $parsed['host'] ?? $parsed['path']; // fallback ke path kalau host kosong
$cleanDomain = strtolower(preg_replace('/^www\./', '', $cleanDomain)); // buang www kalau ada

if (!$cleanDomain || !preg_match('/^[a-z0-9\-\.]+\.[a-z]{2,}$/i', $cleanDomain)) {
  echo json_encode(['status' => 'error', 'message' => 'Domain tidak valid']);
  exit;
}

// 🔁 Cek ke Skiddle
$url = "https://check.skiddle.id/?domain=" . urlencode($cleanDomain);

$ch = curl_init();
curl_setopt_array($ch, [
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_TIMEOUT => 10,
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_USERAGENT => 'Mozilla/5.0'
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if (!$response || $httpCode !== 200) {
  echo json_encode(['status' => 'error', 'message' => 'Gagal fetch']);
  exit;
}

$json = json_decode($response, true);

if (!isset($json[$cleanDomain])) {
  echo json_encode(['status' => 'unknown']);
  exit;
}

if ($json[$cleanDomain]['blocked'] === true) {
  echo json_encode(['status' => 'blocked']);
} elseif ($json[$cleanDomain]['blocked'] === false) {
  echo json_encode(['status' => 'safe']);
} else {
  echo json_encode(['status' => 'unknown']);
}
