<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
require '../../includes/auth.php';
require_login();
require '../../includes/db.php';
header('Content-Type: application/json');

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Unknown';
$id = $_POST['id'] ?? null;

function logActivity($pdo, $userId, $username, $action) {
  $now = date('Y-m-d H:i:s'); // format waktu Asia/Jakarta (sudah diset timezone di atas)
  $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, username, action, created_at) VALUES (?, ?, ?, ?)");
  $stmt->execute([$userId, $username, $action, $now]);
}

// ⛔ Validasi ID
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID domain tidak ditemukan.']);
    exit;
}

// 🔍 Ambil nama domain untuk log
$stmt = $pdo->prepare("SELECT domain FROM list_domains WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $userId]);
$domain = $stmt->fetchColumn();

if (!$domain) {
    echo json_encode(['success' => false, 'message' => 'Domain tidak ditemukan atau bukan milik Anda.']);
    exit;
}

// 🗑️ Hapus domain
$stmt = $pdo->prepare("DELETE FROM list_domains WHERE id = ? AND user_id = ?");
$success = $stmt->execute([$id, $userId]);

if ($success) {
    // ✅ Catat log jika berhasil
    logActivity($pdo, $userId, $username, "Menghapus domain dari daftar: $domain");
}

echo json_encode(['success' => $success]);
