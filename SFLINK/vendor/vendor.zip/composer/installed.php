<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'composer/ca-bundle' => 
    array (
      'pretty_version' => '1.5.7',
      'version' => '1.5.7.0',
      'aliases' => 
      array (
      ),
      'reference' => 'd665d22c417056996c59019579f1967dfe5c1e82',
    ),
    'geoip2/geoip2' => 
    array (
      'pretty_version' => 'v3.2.0',
      'version' => '3.2.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'b7aa58760a6bf89a608dd92ee2d9436b52557ce2',
    ),
    'maxmind-db/reader' => 
    array (
      'pretty_version' => 'v1.12.1',
      'version' => '1.12.1.0',
      'aliases' => 
      array (
      ),
      'reference' => '815939e006b7e68062b540ec9e86aaa8be2b6ce4',
    ),
    'maxmind/web-service-common' => 
    array (
      'pretty_version' => 'v0.10.0',
      'version' => '0.10.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'd7c7c42fc31bff26e0ded73a6e187bcfb193f9c4',
    ),
  ),
);
